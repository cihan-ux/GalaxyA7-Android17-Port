# Manifests

No active local manifest is committed yet: the required common-device/kernel/vendor revisions and a compatible Android 17 source branch must be validated first. A speculative manifest would imply buildability that has not been established.

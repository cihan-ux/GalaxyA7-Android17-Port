# Android 17 feasibility checklist

- [ ] Confirm upstream Android 17 / LineageOS branch names and build-system requirements (do not assume `lineage-24`).
- [ ] Record hashes and pinned revisions for all upstream components.
- [ ] Find and audit `device/samsung/exynos7885-common` source matching the 18.1 device tree.
- [ ] Find and audit corresponding `vendor/samsung` proprietary blob manifests, without publishing blobs.
- [ ] Check kernel source matches shipped device, U5 bootloader, DTBs, and vendor modules.
- [ ] Evaluate Linux kernel 4.4 compatibility with modern Android requirements and legacy vendor HALs.
- [ ] Confirm partition map, A-only/A-B scheme, vendor/odm sizes and recovery support using read-only methods.
- [ ] Determine verified baseline and recovery strategy before experimentation.
- [ ] Prepare a hardware test matrix and evidence/log collection plan.

## Known unknowns

The presence of a generic ARM64 Android 17 image does not establish device compatibility. Existing Android 11-era configuration is an architectural starting point, not a drop-in Android 17 build target.

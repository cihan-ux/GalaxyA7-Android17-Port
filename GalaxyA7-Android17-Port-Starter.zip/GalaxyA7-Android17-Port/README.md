# Galaxy A7 2018 (SM-A750F) — Android 17 / LineageOS Port Research

> **Status: research-only, not buildable or flashable.** No Android 17 ROM has been produced or tested by this project.

Device: Samsung Galaxy A7 (2018), `a7y18lte`, Exynos 7885. Baseline: Android 10 firmware A750FXXU5CVG1 (bootloader U5), reported kernel 4.4.177. Data comes from device screenshots supplied by the owner; actual partition/firmware details must be independently verified before any installation.

## Sources to audit

| Component | Repository / reference | Notes |
|---|---|---|
| Device tree | https://github.com/exynos7885-dev/old_device_samsung_a7y18lte/tree/lineage-18.1 | Android 11-era starting reference. `BoardConfig.mk` includes `exynos7885-common` and `lineage_a7y18lte_defconfig`. |
| Kernel | https://github.com/AKSharma87/android_kernel_samsung_a7y18lte | WIP source; provenance and compatibility not yet verified. |
| Alternate tree | https://github.com/nnhra/android_device_samsung_a7y18lte | WIP reference, not a ready port. |
| Hardware/recovery notes | https://github.com/Hari-Pi/a7y18lte-Resources | Independent third-party resources; validate before use. |
| LineageOS source | https://github.com/LineageOS/android | Upstream reference; confirm current Android 17 branch and device requirements before selecting a manifest. |

**Warning:** Do not confuse Galaxy A7 (2017) `a7y17lte` with Galaxy A7 (2018) `a7y18lte`.

## Milestones

1. Inventory device, common-device, kernel and vendor trees, commits, licenses and firmware dependencies.
2. Reproduce a known working baseline and document feature tests (boot, radio/SIM, Wi-Fi, Bluetooth, fingerprint, cameras, audio, sensors, encryption, USB/MTP).
3. Establish feasibility of Android 17 requirements vs Linux 4.4 kernel, legacy HALs, SELinux, partitions and proprietary blobs.
4. Draft a **non-flashable** experimental device tree branch with isolated, reviewable changes.
5. Attempt a build only on a sufficiently equipped Linux build host; validate artifacts before any hardware testing.
6. Prepare verified recovery images and full backups before contemplating flashing.

## Safety

- No automated flashing, bootloader unlock, `dd`, `fastboot flash`, Odin writes or repartitioning are included.
- Bootloader unlocking can erase data, trip Knox irreversibly and break banking or security features.
- No proprietary Samsung firmware or vendor blobs are redistributed here.
- Never claim a successful port without actual device tests and reproducible logs.

## Repository setup

The connected GitHub integration cannot create repositories. Create a new **private** repository named `GalaxyA7-Android17-Port` under `cihan-ux`, then upload this starter directory (or use `git init`, `git add`, `git commit` and `git push`). Do not set the repo public unless you explicitly decide to.
